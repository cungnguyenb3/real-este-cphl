@extends('admin.master')
@section('content')
<div class="container-fluid">

</div>
@endsection