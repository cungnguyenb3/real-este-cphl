<footer class="site-footer">
      <div class="container">
        <div class="row">
          <div class="col-lg-4">
            <div class="mb-5">
              <h3 class="footer-heading mb-4">Về Nhà Đất Chúng Tôi - CPH</h3>
              <ul class="list-unstyled">
                  <li><a href="#">BĐS Hồ Chí Minh</a></li>
                  <li><a href="#">BĐS Đồng Nai</a></li>
                  <li><a href="#">BĐS Đà Nẵng</a></li>
                  <li><a href="#">BĐS Hà Nội</a></li>
                  <li><a href="#">BĐS Tìm Nhiều Nhất</a></li>
                </ul>
            </div>

            
            
          </div>
          <div class="col-lg-4 mb-5 mb-lg-0">
            <div class="row mb-5">
              <div class="col-md-12">
                <h3 class="footer-heading mb-4">Chuyển Đến</h3>
              </div>
              <div class="col-md-6 col-lg-6">
                <ul class="list-unstyled">
                  <li><a href="#">Trang Chủ</a></li>
                  <li><a href="#">Mua</a></li>
                  <li><a href="#">Cho Thuê</a></li>
                  <li><a href="#">Xem Thể Loại</a></li>
                </ul>
              </div>
              <div class="col-md-6 col-lg-6">
                <ul class="list-unstyled">
                  <li><a href="#">Về Chúng Tôi</a></li>
                  <li><a href="#">Chính Sách Bảo Mật</a></li>
                  <li><a href="#">Liên Hệ</a></li>
                  <li><a href="#">Điều Kiện</a></li>
                </ul>
              </div>
            </div>


          </div>

          <div class="col-lg-4 mb-5 mb-lg-0">
            <h3 class="footer-heading mb-4">Theo Dõi Chúng Tôi Trên</h3>

                <div>
                  <a href="#" class="pl-0 pr-3"><span class="icon-facebook"></span></a>
                  <a href="#" class="pl-3 pr-3"><span class="icon-twitter"></span></a>
                  <a href="#" class="pl-3 pr-3"><span class="icon-instagram"></span></a>
                  <a href="#" class="pl-3 pr-3"><span class="icon-linkedin"></span></a>
                </div>

            

          </div>
          
        </div>
        <div class="row pt-5 mt-5 text-center">
          <div class="col-md-12">
            <p>
            Bản quyền &copy;<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script>document.write(new Date().getFullYear());</script> Thuộc <a href="https://www.google.com/search?q=C%C3%B4ng+ty+TNHH+MTV+CPH&rlz=1C1GCEU_viVN842VN842&oq=C%C3%B4ng+ty+TNHH+MTV+CPH&aqs=chrome..69i57.534j0j7&sourceid=chrome&ie=UTF-8" target="_blank"> Công ty TNHH MTV CPH</a> <i class="icon-heart text-danger" aria-hidden="true"></i>
            </p>
          </div>
          
        </div>
      </div>
    </footer>